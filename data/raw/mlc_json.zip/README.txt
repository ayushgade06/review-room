This zip archive contains data files from Cricsheet in JSON format. This
archive contains 109 Major League Cricket matches.


The JSON data files contained in this zip file are version 1.2.0, and 1.3.0
files. You can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/mlc_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-07-18 - club - MLC - male - 1528590 - Los Angeles Knight Riders vs Washington Freedom
2026-07-16 - club - MLC - male - 1528589 - Washington Freedom vs San Francisco Unicorns
2026-07-15 - club - MLC - male - 1528588 - MI New York vs Washington Freedom
2026-07-15 - club - MLC - male - 1528587 - Los Angeles Knight Riders vs San Francisco Unicorns
2026-07-12 - club - MLC - male - 1528586 - Texas Super Kings vs Los Angeles Knight Riders
2026-07-12 - club - MLC - male - 1528585 - MI New York vs Washington Freedom
2026-07-11 - club - MLC - male - 1528584 - Seattle Orcas vs San Francisco Unicorns
2026-07-11 - club - MLC - male - 1528583 - Texas Super Kings vs Washington Freedom
2026-07-10 - club - MLC - male - 1528582 - Los Angeles Knight Riders vs San Francisco Unicorns
2026-07-10 - club - MLC - male - 1528581 - MI New York vs Seattle Orcas
2026-07-09 - club - MLC - male - 1528580 - Los Angeles Knight Riders vs Washington Freedom
2026-07-08 - club - MLC - male - 1528579 - MI New York vs San Francisco Unicorns
2026-07-05 - club - MLC - male - 1528578 - MI New York vs San Francisco Unicorns
2026-07-05 - club - MLC - male - 1528577 - Seattle Orcas vs Texas Super Kings
2026-07-04 - club - MLC - male - 1528576 - Los Angeles Knight Riders vs MI New York
2026-07-04 - club - MLC - male - 1528575 - San Francisco Unicorns vs Washington Freedom
2026-07-03 - club - MLC - male - 1528574 - Texas Super Kings vs Los Angeles Knight Riders
2026-07-02 - club - MLC - male - 1528573 - MI New York vs Seattle Orcas
2026-07-01 - club - MLC - male - 1528572 - Los Angeles Knight Riders vs Washington Freedom
2026-06-28 - club - MLC - male - 1528571 - Washington Freedom vs San Francisco Unicorns
2026-06-28 - club - MLC - male - 1528570 - Seattle Orcas vs Los Angeles Knight Riders
2026-06-27 - club - MLC - male - 1528569 - Texas Super Kings vs Washington Freedom
2026-06-27 - club - MLC - male - 1528568 - MI New York vs Los Angeles Knight Riders
2026-06-26 - club - MLC - male - 1528567 - Seattle Orcas vs San Francisco Unicorns
2026-06-26 - club - MLC - male - 1528566 - MI New York vs Texas Super Kings
2026-06-25 - club - MLC - male - 1528565 - Seattle Orcas vs Washington Freedom
2026-06-24 - club - MLC - male - 1528564 - Texas Super Kings vs San Francisco Unicorns
2026-06-21 - club - MLC - male - 1528563 - Texas Super Kings vs MI New York
2026-06-21 - club - MLC - male - 1528562 - Los Angeles Knight Riders vs Seattle Orcas
2026-06-20 - club - MLC - male - 1528561 - Washington Freedom vs MI New York
2026-06-20 - club - MLC - male - 1528560 - Texas Super Kings vs San Francisco Unicorns
2026-06-19 - club - MLC - male - 1528559 - Washington Freedom vs Seattle Orcas
2026-06-19 - club - MLC - male - 1528558 - San Francisco Unicorns vs Los Angeles Knight Riders
2026-06-18 - club - MLC - male - 1528557 - Seattle Orcas vs Texas Super Kings
2025-07-13 - club - MLC - male - 1482025 - MI New York vs Washington Freedom
2025-07-11 - club - MLC - male - 1482024 - Texas Super Kings vs MI New York
2025-07-09 - club - MLC - male - 1482023 - San Francisco Unicorns vs MI New York
2025-07-06 - club - MLC - male - 1482021 - Los Angeles Knight Riders vs San Francisco Unicorns
2025-07-06 - club - MLC - male - 1482020 - MI New York vs Washington Freedom
2025-07-05 - club - MLC - male - 1482019 - Texas Super Kings vs Seattle Orcas
2025-07-05 - club - MLC - male - 1482018 - MI New York vs Los Angeles Knight Riders
2025-07-04 - club - MLC - male - 1482017 - Seattle Orcas vs Washington Freedom
2025-07-04 - club - MLC - male - 1482016 - San Francisco Unicorns vs Texas Super Kings
2025-07-03 - club - MLC - male - 1482015 - Los Angeles Knight Riders vs MI New York
2025-07-02 - club - MLC - male - 1482014 - Texas Super Kings vs Washington Freedom
2025-07-01 - club - MLC - male - 1482013 - San Francisco Unicorns vs Seattle Orcas
2025-06-29 - club - MLC - male - 1482012 - Texas Super Kings vs MI New York
2025-06-28 - club - MLC - male - 1482011 - Los Angeles Knight Riders vs Seattle Orcas
2025-06-28 - club - MLC - male - 1482010 - Washington Freedom vs San Francisco Unicorns
2025-06-27 - club - MLC - male - 1482009 - MI New York vs Seattle Orcas
2025-06-26 - club - MLC - male - 1482008 - Los Angeles Knight Riders vs Washington Freedom
2025-06-25 - club - MLC - male - 1482007 - San Francisco Unicorns vs Seattle Orcas
2025-06-24 - club - MLC - male - 1482006 - Texas Super Kings vs Los Angeles Knight Riders
2025-06-23 - club - MLC - male - 1482005 - San Francisco Unicorns vs MI New York
2025-06-22 - club - MLC - male - 1482004 - Texas Super Kings vs Washington Freedom
2025-06-22 - club - MLC - male - 1482003 - Seattle Orcas vs Los Angeles Knight Riders
2025-06-21 - club - MLC - male - 1482002 - MI New York vs Washington Freedom
2025-06-20 - club - MLC - male - 1482001 - Texas Super Kings vs San Francisco Unicorns
2025-06-18 - club - MLC - male - 1482000 - Seattle Orcas vs MI New York
2025-06-17 - club - MLC - male - 1481999 - Washington Freedom vs Los Angeles Knight Riders
2025-06-16 - club - MLC - male - 1481998 - Texas Super Kings vs Seattle Orcas
2025-06-15 - club - MLC - male - 1481997 - MI New York vs San Francisco Unicorns
2025-06-15 - club - MLC - male - 1481996 - Texas Super Kings vs Los Angeles Knight Riders
2025-06-14 - club - MLC - male - 1481995 - Seattle Orcas vs Washington Freedom
2025-06-14 - club - MLC - male - 1481994 - San Francisco Unicorns vs Los Angeles Knight Riders
2025-06-13 - club - MLC - male - 1481993 - Texas Super Kings vs MI New York
2025-06-12 - club - MLC - male - 1481992 - San Francisco Unicorns vs Washington Freedom
2024-07-28 - club - MLC - male - 1432750 - Washington Freedom vs San Francisco Unicorns
2024-07-26 - club - MLC - male - 1432749 - San Francisco Unicorns vs Texas Super Kings
2024-07-25 - club - MLC - male - 1432748 - San Francisco Unicorns vs Washington Freedom
2024-07-24 - club - MLC - male - 1432747 - MI New York vs Texas Super Kings
2024-07-23 - club - MLC - male - 1432746 - Texas Super Kings vs Seattle Orcas
2024-07-22 - club - MLC - male - 1432745 - Washington Freedom vs San Francisco Unicorns
2024-07-21 - club - MLC - male - 1432744 - Los Angeles Knight Riders vs MI New York
2024-07-20 - club - MLC - male - 1432743 - Seattle Orcas vs San Francisco Unicorns
2024-07-19 - club - MLC - male - 1432742 - Washington Freedom vs Texas Super Kings
2024-07-18 - club - MLC - male - 1432741 - San Francisco Unicorns vs MI New York
2024-07-17 - club - MLC - male - 1432740 - Seattle Orcas vs Los Angeles Knight Riders
2024-07-16 - club - MLC - male - 1432739 - Washington Freedom vs MI New York
2024-07-15 - club - MLC - male - 1432738 - San Francisco Unicorns vs Seattle Orcas
2024-07-14 - club - MLC - male - 1432737 - Texas Super Kings vs MI New York
2024-07-14 - club - MLC - male - 1432736 - Los Angeles Knight Riders vs Washington Freedom
2024-07-11 - club - MLC - male - 1432733 - Seattle Orcas vs Washington Freedom
2024-07-10 - club - MLC - male - 1432732 - San Francisco Unicorns vs Texas Super Kings
2024-07-09 - club - MLC - male - 1432731 - Los Angeles Knight Riders vs Seattle Orcas
2024-07-08 - club - MLC - male - 1432730 - Texas Super Kings vs Washington Freedom
2024-07-07 - club - MLC - male - 1432729 - Los Angeles Knight Riders vs San Francisco Unicorns
2024-07-06 - club - MLC - male - 1432728 - MI New York vs Washington Freedom
2024-07-05 - club - MLC - male - 1432727 - Los Angeles Knight Riders vs Texas Super Kings
2024-07-05 - club - MLC - male - 1432726 - Seattle Orcas vs MI New York
2023-07-30 - club - MLC - male - 1381379 - Seattle Orcas vs MI New York
2023-07-28 - club - MLC - male - 1381378 - Texas Super Kings vs MI New York
2023-07-27 - club - MLC - male - 1381377 - Texas Super Kings vs Seattle Orcas
2023-07-27 - club - MLC - male - 1381376 - MI New York vs Washington Freedom
2023-07-25 - club - MLC - male - 1381375 - MI New York vs Seattle Orcas
2023-07-24 - club - MLC - male - 1381374 - San Francisco Unicorns vs Texas Super Kings
2023-07-23 - club - MLC - male - 1381373 - Washington Freedom vs MI New York
2023-07-23 - club - MLC - male - 1381372 - Seattle Orcas vs Los Angeles Knight Riders
2023-07-22 - club - MLC - male - 1381371 - Washington Freedom vs San Francisco Unicorns
2023-07-21 - club - MLC - male - 1381370 - Texas Super Kings vs Seattle Orcas
2023-07-20 - club - MLC - male - 1381369 - Los Angeles Knight Riders vs Washington Freedom
2023-07-18 - club - MLC - male - 1381368 - San Francisco Unicorns vs Los Angeles Knight Riders
2023-07-17 - club - MLC - male - 1381367 - Texas Super Kings vs MI New York
2023-07-16 - club - MLC - male - 1381366 - MI New York vs Los Angeles Knight Riders
2023-07-16 - club - MLC - male - 1381365 - Washington Freedom vs Texas Super Kings
2023-07-15 - club - MLC - male - 1381364 - Seattle Orcas vs San Francisco Unicorns
2023-07-14 - club - MLC - male - 1381363 - Washington Freedom vs Seattle Orcas
2023-07-14 - club - MLC - male - 1381362 - San Francisco Unicorns vs MI New York
2023-07-13 - club - MLC - male - 1381361 - Texas Super Kings vs Los Angeles Knight Riders

Match data is licensed for use under the Open Data Commons Attribution
License. The full license text is included in this download in the LICENSE.txt
file.
